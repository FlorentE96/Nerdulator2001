#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_DIALOG1                             100
#define RESULT_BOX                              40000
#define DIGIT1                                  50001
#define DIGIT2                                  50002
#define DIGIT3                                  50003
#define DIGIT5                                  50004
#define DIGIT4                                  50005
#define DIGIT6                                  50006
#define DIGIT7                                  50007
#define DIGIT8                                  50008
#define DIGIT9                                  50009
#define DIGIT0                                  50010
#define OP_DIV                                  40011
#define OP_MUL                                  40012
#define OP_SUM                                  40013
#define OP_NOT                                  40014
#define OP_SUB                                  40015
#define OP_AND                                  40016
#define OP_OR                                   40017
#define OP_XOR                                  40018
#define SEL_DEC                                 60019
#define SEL_BIN                                 60020
#define BUT_QUIT                                40021
#define BUT_ABOUT                               40022
#define OP_EQ                                   30023
#define BUT_C                                   40024
